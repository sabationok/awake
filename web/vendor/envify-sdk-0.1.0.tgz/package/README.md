# @envify/sdk

Fetches a service's resolved config from Envify at boot. One service token = one project / environment / service;
the token fixes the scope, so a service can never read another one's variables.

## Install (from GitHub, until it is on npm)

```bash
npm i github:sabationok/envify#sdk-v0.1.0
```

The `sdk` branch holds only the built package (released with `pnpm release:sdk -- --push` in the envify repo).
The repo is private: a CI that installs it (Vercel, Railway) needs read access to it — see "Private repo" below.

## Environment

| Variable | Meaning |
| --- | --- |
| `ENVIFY_URL` | Envify base URL, e.g. `https://envify-manager.vercel.app` |
| `ENVIFY_TOKEN` | Service token (`envify_…`) from the service's **Connect** tab |
| `ENVIFY_OVERRIDE=1` | Envify values win over variables already set (default: already-set wins) |

Without `ENVIFY_TOKEN` the preload and `envify run` do nothing, so local `.env` setups keep working.

## Ways to load

```bash
envify run -- node dist/main.js          # child process gets the variables
node --import @envify/sdk/register dist/main.js   # preload, Node ≥ 20.6, works for CJS apps too
envify pull --out .env.local             # write a file (mode 0600)
```

```ts
import { loadEnv, fetchConfig } from '@envify/sdk';
await loadEnv();                          // into process.env
const { variables, errors } = await fetchConfig({ strict: true }); // read only; strict throws on unresolved refs
```

Network errors and 5xx are retried (2 retries, 10s timeout); 401/403/404 fail at once. A failed load must stop
the boot: a service without its config should crash, not run half-configured.

## NestJS (`@nestjs/config`)

`ConfigModule.forRoot()` reads `process.env` — and runs its validation schema — when `AppModule` is imported,
so the variables have to be in `process.env` before that import. Pick one:

1. **Preload (preferred, no code change):**
   ```json
   "start:prod": "node --import @envify/sdk/register dist/main",
   "start:dev": "envify run -- nest start --watch"
   ```
2. **In `main.ts`**, importing the module only after loading:
   ```ts
   import { loadEnv } from '@envify/sdk';

   async function bootstrap() {
     if (process.env.ENVIFY_TOKEN) await loadEnv();
     const { AppModule } = await import('./app.module');
     const app = await NestFactory.create(AppModule);
     // …
   }
   ```
   Do not `import { AppModule }` statically at the top of this file — the import would run first.

3. **As a Nest module** (`@envify/sdk/nest`, needs `@nestjs/common` ≥ 9), when code should read Envify explicitly:
   ```ts
   import { EnvifyModule, EnvifyService, envifyLoader } from '@envify/sdk/nest';

   @Module({
     imports: [
       EnvifyModule.forRoot({ isGlobal: true }),             // or forRootAsync({ inject: [ConfigService], useFactory })
       ConfigModule.forRoot({ load: [envifyLoader()] }),    // ConfigService.get('JWT_SECRET') sees Envify values
       // ConfigModule.forRoot({ load: [registerAs('envify', envifyLoader())] }) → get('envify.JWT_SECRET')
     ],
   })
   export class AppModule {}

   constructor(private readonly envify: EnvifyService) {}
   this.envify.getSecret('JWT_SECRET'); // throws if missing; get(key, fallback?), getConfig(), refresh()
   ```
   ConfigModule's `validationSchema` checks `process.env` before load factories run, so it does not see values
   from `envifyLoader()`; when the schema must cover them, use the preload (1) instead or in addition.

Keep `envFilePath` / `.env` for local runs: `@nestjs/config` does not overwrite variables that are already set,
so Envify values win over the file and the real environment wins over both.

## Next.js

- **Server runtime (app and pages router, Next ≥ 13.4):** `instrumentation.ts` at the project root (or `src/`):
  ```ts
  export async function register() {
    if (process.env.NEXT_RUNTIME === 'nodejs' && process.env.ENVIFY_TOKEN) {
      const { loadEnv } = await import('@envify/sdk');
      await loadEnv();
    }
  }
  ```
  It runs once per server instance before any request. On Vercel that is once per cold start: one extra request.
  Read env inside handlers or lazily, not in module scope of files that `next.config` imports.
- **Build time:** `NEXT_PUBLIC_*` and anything read during `next build` are inlined then, so the build needs
  them too: `"build": "envify run -- next build"`.
- **Edge runtime / middleware:** cannot load at runtime; it only sees build-time values.

## Private repo

`github:sabationok/envify#…` installs on your machine (your git credentials), but a CI build (Vercel, Railway)
has no access to a private repo. Until the package is on npm, either:

- **vendor the tarball** — `npm pack github:sabationok/envify#sdk-v0.1.0`, commit the `.tgz` to the consumer
  (e.g. `vendor/`), depend on `"@envify/sdk": "file:vendor/envify-sdk-0.1.0.tgz"`; or
- push the `sdk` branch to a separate **public** repo (the SDK holds no secrets) and install from that.

Publishing to npm removes this step.
